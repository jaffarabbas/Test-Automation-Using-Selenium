﻿using System;
namespace TestProject
{
    public class EmptyClass
    {
        public EmptyClass()
        {
        }
    }
}
